
function showAlert() {
  alert("Thank you for contacting me! I will get back to you soon.");
  return false;
}
